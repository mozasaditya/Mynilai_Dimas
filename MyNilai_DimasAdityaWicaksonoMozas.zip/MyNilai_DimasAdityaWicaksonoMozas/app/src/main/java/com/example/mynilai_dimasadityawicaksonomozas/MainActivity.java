package com.example.mynilai_dimasadityawicaksonomozas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener  {

    String text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //panggil Spinner
        Spinner spinner = findViewById(R.id.spinner); //memanggil id spinner yang ada di
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.matkul, android.R.layout.simple_spinner_item) //untuk mengambil isi drop down
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
    }

    @Override
    public  void setOnItemSelectedListener(AdapterView<?> parent,View view, int position,long id) {
        text = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    public void btnext(View view) {
        Intent i = new Intent(PackageContext() this, InputNilaiActivity.class);
        i.putExtra( name "matkul",text);
        startActivity(i);
    }
}