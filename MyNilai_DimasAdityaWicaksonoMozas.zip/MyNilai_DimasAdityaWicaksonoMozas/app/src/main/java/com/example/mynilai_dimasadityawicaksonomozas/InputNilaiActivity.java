package com.example.mynilai_dimasadityawicaksonomozas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.PackageManagerCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class InputNilaiActivity extends AppCompatActivity {

    EditText nim, nama, kehadiran, tugas, uts, uas;
    Button Bsubmit;
    String matkul;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_nilai);

        matkul = getIntent().getExtras().getString();
        nim = findViewById(R.id.nim);
        nama = findViewById(R.id.nama)
        kehadiran = findViewById(kehadiran);
        tugas = findViewById(tugas);
        uts = findViewById(uts);
        uas = findViewById(uas);

        Bsubmit = findViewById(R.id.submit);
        Bsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(packageContext InputNilaiActivity.class)
                i.putExtra("kehadiran", kehadiran.getText().toString());
                i.putExtra("tugas", tugas.getText().toString());
                i.putExtra("uts", uts.getText().toString());
                i.putExtra("uas", uas.getText().toString());
                i.putExtra("nama", nama.getText().toString());
                i.putExtra("nim", nim.getText().toString());
                i.putExtra("matkul", matkul);
                startActivity(i);

            }
        }
